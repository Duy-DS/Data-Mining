print("Calculator Basic")
a = int(input("Moi ban nhap so a: "))
b = int(input("Moi ban nhap so b: "))
c = a + b
print("c = %d + %d = %d" % (a, b, c))
